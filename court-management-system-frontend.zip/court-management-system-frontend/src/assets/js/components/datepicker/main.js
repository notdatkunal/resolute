$(function() {

   $('#pick-date').pickadate();

});