export const constants = {
  // serverUrl: 'https://localhost:8080',
  serverUrl: 'https://103.175.23.176:8080',
}
